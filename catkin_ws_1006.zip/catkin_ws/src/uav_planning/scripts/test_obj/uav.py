#! /usr/bin/env python
import math
import numpy as np
from cvxopt import matrix, solvers



# global t_0, t_pre, gamma_0, gamma_inf, l 
# class-level variable



class UAV:

    # goal = ()
    # k = None
    # rho = None
    # t_star = None
    # attractive_gain = 0.1
    # repulsive_gain = 15

    # t_0 = 0
    # t_pre = 0
    # gamma_0 = 0
    # gamma_inf = 0.3
    # l = 0
    # b = 0
    

    def __init__(self):
        # global t_0, t_pre, gamma_0, gamma_inf, l 
        # global k, rho, t_star, goal, attractive_gain, repulsive_gain
        self.k = None
        self.rho = None
        self.t_star = None
        self.goal = () # [x,y,R]
        self.attractive_gain = 0.1 # Example attractive gain
        self.repulsive_gain = 15
        
        self.t_0 = 0
        self.t_pre = 0
        self.gamma_0 = 0
        self.gamma_inf = 0.3
        self.l = 0
        self.b = 0

    def set_parameters(self, goal, k ,rho, t_star, attractive_gain= 0.1, repulsive_gain = 15):
        self.goal = goal
        self.k = k 
        self.rho = rho
        self.t_star = t_star
        self.attractive_gain = attractive_gain # Example attractive gain
        self.repulsive_gain = repulsive_gain
        

    def gamma_param(self, x, delta = 0.1, r = 0.1, l_max = 0.9):
        '''
        delta = 0.1 # intial inside the forward invariant set 
        r = 0.1  # the robustness of the formulas 
        l_max = 0.9 # bound for l
        gamma_inf = 0.3
        '''

        h_0 = self.goal[-1] - math.sqrt( (x[0] - self.goal[0])**2 + (x[1] - self.goal[1])**2 )
        self.gamma_0 = h_0 - delta
        if self.gamma_inf > self.goal[-1]:
            self.gamma_inf = self.goal[-1]
        else:
            self.gamma_inf = self.gamma_inf

        if self.t_star > 0:
            if self.l <= l_max:
                # print("r" + str(r))
                # print("gamma_inf" + str(self.gamma_inf))
                # print("gamma_0" + str(self.gamma_0))
                # print("gamma_inf" + str(self.gamma_inf))
                # print((r-self.gamma_inf)/(self.gamma_0 -self.gamma_inf))
                self.l =  ( -math.log( (r-self.gamma_inf)/(self.gamma_0 -self.gamma_inf) ) ) / self.t_star 
                print("l" + str(self.l))
                if self.l > l_max:
                    self.l = l_max 
            else:
                self.l = l_max 
            # 
            # if l >l_max:
            #     l = l_max
        else:
            self.l = l_max
            # print("cccccccccccccccccccccccccccccccccccccccccccc")

        # return self.gamma_0, self.gamma_inf, self.l



    def CBF_generator_updates(self, x, t):
        delta_t = t - self.t_pre
        self.t_pre = t
        p_h_x1 = (-1/2) * ( ( (x[0] - self.goal[0])**2 + (x[1] - self.goal[1])**2 ) **(-1/2) ) * 2 * (x[0] - self.goal[0])
        p_h_x2 = (-1/2) * ( ( (x[0] - self.goal[0])**2 + (x[1] - self.goal[1])**2 ) **(-1/2) ) * 2 * (x[1] - self.goal[1])
        p_b_x1 = p_h_x1
        p_b_x2 = p_h_x2

        h = self.goal[-1] - math.sqrt((x[0] - self.goal[0])**2 + (x[1] - self.goal[1])**2)

        if self.t_0 == 0:
            self.t_0 = t
            self.gamma_param(x)
            gamma = (self.gamma_0 - self.gamma_inf) * math.exp(-self.l * (t - self.t_0)) + self.gamma_inf 
            h = self.goal[-1] - math.sqrt((x[0] - self.goal[0])**2 + (x[1] - self.goal[1])**2)
            self.b = h - gamma 
            print("aaaaaaaaaaaaaaaaaaaaa")
        else:
            if self.b < 0:
                self.t_0 = t
                self.gamma_param(x)
                gamma = (self.gamma_0 - self.gamma_inf) * math.exp(-self.l * (t - self.t_0)) + self.gamma_inf
                h = self.goal[-1] - math.sqrt((x[0] - self.goal[0])**2 + (x[1] - self.goal[1])**2)
                self.b = h - gamma
                print("update")
            else:
                h = self.goal[-1] - math.sqrt((x[0] - self.goal[0])**2 + (x[1] - self.goal[1])**2)
                gamma = (self.gamma_0 - self.gamma_inf) * math.exp(-self.l * (t - self.t_0)) + self.gamma_inf
                self.b = h - gamma
                print(" No update")
                if self.b < 0 or delta_t < 0:
                    self.t_0 = t
                    self.gamma_param(x)
                    gamma = (self.gamma_0 - self.gamma_inf) * math.exp(-self.l * (t - self.t_0)) + self.gamma_inf 
                    h = self.goal[-1] - math.sqrt((x[0] - self.goal[0])**2 + (x[1] - self.goal[1])**2)
                    self.b = h - gamma 
                    print("update")
        b_t = - ( -self.l * (self.gamma_0 - self.gamma_inf) * math.exp(-self.l*(t - self.t_0)) )
        return h, gamma, self.b, p_b_x1, p_b_x2, b_t




    def CBF_controller_updates(self,x,t):

        # Define the quadratic cost matrix
        P = matrix(np.array([[2.0, 0.0], [0.0, 2.0]]))

        # Define the linear cost vector
        q = matrix(np.array([0.0, 0.0]))

        # calculate the CBF 
        # print(t)

        h , gamma, b, p_b_x1, p_b_x2, b_t= self.CBF_generator_updates(x, t) 
        # print("l"+str(l))


        # Define the inequality constraint matrix
        G = matrix(np.array([[-p_b_x1, -p_b_x2]])) 

        # Define the inequality constraint vector
        h1 = matrix(np.array([ self.k*(b) -self.rho + b_t ]))

        

        # Solve the quadratic programming problem
        solvers.options['show_progress'] = False  # Disable solver progress output
        sol = solvers.qp(P, q, G, h1)

        # Extract the optimal solution
        optimal_solution = np.array(sol['x'])
        # Extract the objective value
        objective_value = sol['primal objective']

        v1 = optimal_solution[0,0]
        v2 = optimal_solution[1,0]

        return v1, v2, h, gamma, b, b_t



    def potential_field_dynamic(self, x, obstacles):
        # Calculate attractive force
        dx = self.goal[0] - x[0]
        dy = self.goal[1] - x[1]
        distance_to_goal = math.sqrt(dx**2 + dy**2)
        attractive_force_x = self.attractive_gain * dx 
        attractive_force_y = self.attractive_gain * dy 
        # print(attractive_force_x)
        # Calculate repulsive forces
        repulsive_force_x = 0
        repulsive_force_y = 0
        for obstacle in obstacles:
            ox, oy, oR = obstacle
            dx = x[0] - ox
            dy = x[1] - oy
            if oR <=1:
                repulsive_radius = oR + 1
            else:
                repulsive_radius = oR + 1.8
            distance_to_obstacle = math.sqrt(dx**2 + dy**2)
            if distance_to_obstacle < repulsive_radius:
                repulsive_force_x += self.repulsive_gain * (1 / distance_to_obstacle - 1 / repulsive_radius) * (dx / distance_to_obstacle**3)
                repulsive_force_y += self.repulsive_gain * (1 / distance_to_obstacle - 1 / repulsive_radius) * (dy / distance_to_obstacle**3)
                # print(repulsive_gain)
                # print(1 / distance_to_obstacle - 1 / repulsive_radius)
                # print(1 / distance_to_obstacle**3)

        # Calculate total force
        total_force_x = attractive_force_x + repulsive_force_x
        total_force_y = attractive_force_y + repulsive_force_y
        # if math.sqrt(total_force_x**2 + total_force_y**2) <1:
        #     total_force_x = total_force_x +  random.uniform(0, 0.)
        #     total_force_y = total_force_y +  random.uniform(0, 1)
        return total_force_x, total_force_y


    def regulation_function(self, v1_cpf, v2_cpf, v1_cbf, v2_cbf, x,obstacles):
        eta = 10
        beta = 0.1
        h_in = 0
        for obstacle in obstacles:
            ox, oy, oR = obstacle
            R_star = oR + 0.5
            h_star =  math.sqrt( (x[0] - ox)**2 + (x[1] - oy)**2 ) - R_star
            # print(math.sqrt( (x[0] - ox)**2 + (x[1] - oy)**2 ) - oR)
            h_in +=  math.exp(-eta * h_star)
        
        h_obs = (-1/eta) * math.log( h_in )
        h_obs_positive = max(h_obs,0)
        lambda_s = 1 - math.exp(-beta * h_obs_positive) 
        # print("lambda"+ str(lambda_s))
        u1 = lambda_s * v1_cbf + (1- lambda_s) * v1_cpf
        u2 = lambda_s * v2_cbf + (1- lambda_s) * v2_cpf
        return u1, u2

    def laser_data_process(self, laser_data, angle_increment, angle_min, UAV_x, UAV_y):
        index_first_para=[]
        paragraphs = []
        current_paragraph = []
        all_inf = True

        for num in laser_data:
            if num != float('inf'):
                current_paragraph.append(num)
                all_inf = False
            else:
                if current_paragraph:
                    paragraphs.append(current_paragraph)
                    current_paragraph = []



        # for num in laser_data:
        #     if num == float('inf'):
        #         check_index = laser_data.index(num) + 1
        #         if check_index > len(laser_data) -1:
        #             check_index = 0
        #             if laser_data[check_index] != float('inf'):
        #                 index_first_para.append(check_index)
        #                 print(index_first_para)
        #         else:
        #             if laser_data[check_index] != float('inf'):
        #                 index_first_para.append(check_index)
        #                 print(index_first_para)
        
        # find the index of the first number after inf
        for i, num in enumerate(laser_data):
            if num == float('inf'):
                check_index = i + 1
                if check_index <= len(laser_data)-1:
                    if laser_data[check_index] != float('inf'):
                        index_first_para.append(check_index)
                else:
                    check_index = 0
                    if laser_data[check_index] != float('inf'):
                        index_first_para.append(check_index)


        # print(index_first_para)


        # Handle cyclic connection between first and last numbers
        if laser_data[0] != float('inf') and laser_data[-1] != float('inf'):
            current_paragraph.extend(paragraphs[0])
            paragraphs = paragraphs[1:]
            paragraphs.append(current_paragraph)

        # Find the largest and smallest numbers within each paragraph
        obs_positions = []

        for i, paragraph in enumerate(paragraphs):
            largest = max(paragraph)
            smallest = min(paragraph)
            smallest_index_paragraph = paragraph.index(smallest)  # Get the index of the smallest number within the paragraph
            if laser_data[0] != float('inf') and laser_data[-1] != float('inf'):
                smallest_index = index_first_para[i] + smallest_index_paragraph 
                if smallest_index > len(laser_data) -1:
                    smallest_index = (smallest_index % (len(laser_data)-1))-1
            else:
                if laser_data[0] != float('inf'):
                    if i == 0:
                        smallest_index = index_first_para[-1] + smallest_index_paragraph 
                    else:
                        smallest_index = index_first_para[i-1] + smallest_index_paragraph 
                else:
                    smallest_index =index_first_para[i] + smallest_index_paragraph 

            angle = angle_min + angle_increment * smallest_index

            R = ((largest + 0.08)**2 -(smallest)**2)/ (2*smallest)
            if R <= 0.4:
                continue

            delta_x = (R + smallest) * math.cos(angle)
            delta_y = (R + smallest) * math.sin(angle)

            x = UAV_x + delta_x
            y = UAV_y + delta_y

            obs_positions.append((x, y, R))
            # largest_smallest_pairs.append((delta_x, delta_y))

        # Handle the case when all numbers are infinite
        if all_inf:
            obs_positions.append((float('inf'), 0, float('inf')))

        return obs_positions
