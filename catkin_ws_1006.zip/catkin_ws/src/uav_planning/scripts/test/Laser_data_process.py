import math 

def laser_data_process(laser_data, angle_increment, angle_min, UAV_x, UAV_y):
    index_first_para=[]
    paragraphs = []
    current_paragraph = []
    all_inf = True

    for num in laser_data:
        if num != float('inf'):
            current_paragraph.append(num)
            all_inf = False
        else:
            if current_paragraph:
                paragraphs.append(current_paragraph)
                current_paragraph = []



    # for num in laser_data:
    #     if num == float('inf'):
    #         check_index = laser_data.index(num) + 1
    #         if check_index > len(laser_data) -1:
    #             check_index = 0
    #             if laser_data[check_index] != float('inf'):
    #                 index_first_para.append(check_index)
    #                 print(index_first_para)
    #         else:
    #             if laser_data[check_index] != float('inf'):
    #                 index_first_para.append(check_index)
    #                 print(index_first_para)
    
    # find the index of the first number after inf
    for i, num in enumerate(laser_data):
        if num == float('inf'):
            check_index = i + 1
            if check_index <= len(laser_data)-1:
                if laser_data[check_index] != float('inf'):
                    index_first_para.append(check_index)
            else:
                check_index = 0
                if laser_data[check_index] != float('inf'):
                    index_first_para.append(check_index)


    # print(index_first_para)


    # Handle cyclic connection between first and last numbers
    if laser_data[0] != float('inf') and laser_data[-1] != float('inf'):
        current_paragraph.extend(paragraphs[0])
        paragraphs = paragraphs[1:]
        paragraphs.append(current_paragraph)

    # Find the largest and smallest numbers within each paragraph
    obs_positions = []

    for i, paragraph in enumerate(paragraphs):
        largest = max(paragraph)
        smallest = min(paragraph)
        smallest_index_paragraph = paragraph.index(smallest)  # Get the index of the smallest number within the paragraph
        if laser_data[0] != float('inf') and laser_data[-1] != float('inf'):
            smallest_index = index_first_para[i] + smallest_index_paragraph 
            if smallest_index > len(laser_data) -1:
                smallest_index = (smallest_index % (len(laser_data)-1))-1
        else:
            if laser_data[0] != float('inf'):
                if i == 0:
                    smallest_index = index_first_para[-1] + smallest_index_paragraph 
                else:
                    smallest_index = index_first_para[i-1] + smallest_index_paragraph 
            else:
                smallest_index =index_first_para[i] + smallest_index_paragraph 

        angle = angle_min + angle_increment * smallest_index

        R = ((largest + 0.08)**2 -(smallest)**2)/ (2*smallest)
        if R <= 0.4:
            continue

        delta_x = (R + smallest) * math.cos(angle)
        delta_y = (R + smallest) * math.sin(angle)

        x = UAV_x + delta_x
        y = UAV_y + delta_y

        obs_positions.append((x, y, R))
        # largest_smallest_pairs.append((delta_x, delta_y))

    # Handle the case when all numbers are infinite
    if all_inf:
        obs_positions.append((float('inf'), 0, float('inf')))

    return obs_positions

# my_tuple = (float('inf'), float('inf'), float('inf'), float('inf'))
# my_tuple = (1, 3, 2, float('inf'), float('inf'), 30, 10, 20, float('inf'), 4, 3, 9, 2, 2)
# largest_smallest_pairs = laser_data_process(my_tuple, 0.017, -3.14)
# print(largest_smallest_pairs)
# print(largest)
# print(smallest)